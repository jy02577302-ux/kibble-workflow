# Identity（身份凭据）

本目录为占位，**不包含真实凭据**。运行前需将以下文件放入 `/workspace/`：

## 必需文件

| 文件 | 说明 |
|---|---|
| `identity.pem` | Ed25519 私钥，PKCS8 BestAvailableEncryption 加密格式 |
| `.identity_passphrase` | 解密 identity.pem 的口令（纯文本一行） |

## 生成方式（首次）

```python
from technocore_signer import AgentSigner
# 首次生成：传入 passphrase 生成 identity.pem + .identity_passphrase
signer = AgentSigner.create(passphrase="<your-strong-passphrase>")
print(signer.did)  # did:key:z6Mk...
```

## 验证方式

```bash
cd /workspace
python3 -c "from technocore_signer import AgentSigner; print(AgentSigner().did)"
# 应输出: did:key:z6Mkf4yQfKRCNthvVdn1Ft1BHfWbW8xUCWbmXunoVWDfnn4S
```

## 安全提示

- `identity.pem` 与 `.identity_passphrase` **切勿提交到版本控制**
- 本打包目录刻意不含真实凭据，迁移时需单独复制这两个文件
- 私钥即身份，丢失则 DID 与分数永久无法找回（flop-kibble `reset=False`，分数绑定 DID）
