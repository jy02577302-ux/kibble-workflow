---
name: "kibble_progress"
description: "Reports Kibble/Technocore agent progress with 4-way evidence cross-check (processes + monitor ticks + structured summary + official HTTP score). Invoke whenever user asks 'how's the progress / 进度如何' for any vN r200/run20 cycle."
---

# Kibble Progress 4-Way Evidence Report

This skill standardises a **non-voluntary 4-evidence cross-check** progress report for
Technocore / Kibble long-running agent cycles (r200_v1 / r200_v2 / r200_v3 / r200_v4 / ...).
It must be used **every single time** the user asks a progress question — never re-use
numbers from the previous turn.

## When to invoke

* User asks, verbatim or near-verbatim:  **进度如何 / how is it going / progress / what's the score now / status check**.
* After launching a new cycle, before replying to the user "done", as the final acceptance smoke-test.
* Whenever the user is going to compare a *previous* score with a *current* score (to avoid "原地踏步" / stale-number regressions — see Experience 186074).

## Hard rules

1. **Fresh polling only.**  Do NOT cite `score / rounds_so_far / verdict` from memory.
   Run the Bash block in section "Execution Template" once per progress query.
2. **Four independent evidence sources.** Output order A → B → C → D. Every section must
   be present; if a file is missing / HTTP call failed, print the raw exception text
   instead of skipping.
3. **Official HTTP = absolute truth.** Always override any local counter
   (useful / not / jobs_posted / attests_given) with the `/api/score?did=<did>` JSON
   terms. When a delta exists, print `OFFICIAL diff: X→Y` in red/log form. (Experience 609014)
4. **No destructive ops in progress-only queries.** If the user only asked "progress",
   **never** issue `pkill / rm -rf / DeleteFile / mv` of summary/log/backup files.
5. **Kibble-score-v2 formula verification is mandatory.** Sum the breakdown
   `Σ points = jobs_posted×2 + results_delivered×1 + useful×6 + not×-3 +
   attests_given×1 + poster_accepts×1 + briefs×1` and assert it equals `score`.
   If mismatch, print `⚠ Σ mismatch` with the number.
6. **TOP48 gap is mandatory.** Compute gap = `api/stats passports[-1].score - mine.score`
   and convert to approximate useful ×6 / jobs_posted ×2 / attests_given ×1 equivalents.

## Evidence Sections (always output in order)

### A. 进程存活 (Processes alive — real ps / pgrep)

Run `pgrep -af kibble` AND `ps -p <old-pids> -o pid,etime,%cpu,rss,cmd --no-headers`;
list *every* kibble-related PID. If watchdog / run20 / monitor are all dead, print
`💥 ALL PROCESSES DOWN`; if only one is down, label which.

### B. monitor tick

Check `kibble_monitor.log` first (start scripts default-output there), then
`kibble_monitor_v2.log`, `kibble_monitor_v3.log`, `kibble_monitor_v4.log` in size order.
Print last 6 ticks. If file is zero-length, state clearly which file is active.

### C. run20 structured summary

Open `kibble_r200_v<N>_summary.json` for the active cycle. Print:

* `started_at / updated_at`
* `rounds_so_far / total_rounds_configured` with percentage
* `elapsed_minutes`, per-round-minute throughput, **ETA by rounds** and
  (if available) ETA by configured `total_minutes`
* `score.init → score.last` (from summary — later overridden by official in D)
* `job_submitted / useful / not / no_attest`
* Top-6 verdict/skip distribution via Counter
* Last 6 rounds with `round / jid / verdict / poll_rounds / bump_count / seconds`

### D. Official HTTP /api/score (absolute truth)

HTTP GET `https://flop-kibble.onrender.com/api/score?did=<my_did>` with proxy-awareness
(use `urllib.request.ProxyHandler({'http':PROXY,'https':PROXY})` when HTTPS_PROXY set).
Print the 7-row breakdown table then the Σ check, then:

* (D-1) Baseline delta vs *session-start hard baseline*:
  `rs=51 us=2 no=16 jp=0 score=15`. Compute calc = Δrs + Δus×6 + Δno×-3 +
  Δjp×2 + Δag + Δpa + Δbr and compare to official Δscore; mark `✅` or `⚠ pump差`.
* (D-2) vs **previous progress-query's score** (stored in-conversation): print
  `Δ=+X` and attribute each changed term (jp/us/rs/ag/not change with point delta).
* (D-3) TOP48: GET `/api/stats`, sort `passports` by score desc; report
  TOP1 / TOP48 threshold / my rank (if in top passports list else TOP N+ estimation)
  and gap converted to useful / jobs_posted / ATTEST-given equivalents.

## Execution Template

Use this exact shell block on `/workspace`. Replace `VN` (e.g. v2/v3/v4) for the
currently-active cycle. Placeholders wrapped in `<...>` must be substituted.

```bash
cd /workspace

# A. processes
echo "===== A. 进程存活 ====="
pgrep -af kibble | awk '{printf "  %s\n", $0}'
ps -p <PID1>,<PID2>,<PID3> -o pid,etime,%cpu,rss,cmd --no-headers 2>/dev/null \
  || echo "  (some PIDs exited / not yet recorded)"

# B. monitor ticks
echo ""; echo "===== B. monitor 最近 6 tick ====="
for f in kibble_monitor.log kibble_monitor_v2.log kibble_monitor_v3.log kibble_monitor_v4.log; do
  sz=$(stat -c%s "$f" 2>/dev/null || echo 0)
  echo "  $f size=$sz"
  if [ "$sz" -gt 0 ]; then tail -n 6 "$f" | sed 's/^/    /'; echo; fi
done

# C. tail latest vN log
echo "===== C. run20 log tail 26 ====="
tail -n 26 kibble_r200_VN.log 2>/dev/null || echo "  (no VN log yet)"

echo ""; echo "===== D. summary ====="
python3 << PYEOF
import json
from collections import Counter
try:
  with open("kibble_r200_VN_summary.json") as f: d = json.load(f)
except Exception as e:
  print("  summary MISSING / PARSE ERR:", type(e).__name__, str(e)[:120])
  raise SystemExit(0)
rs = d.get("results") or []
vc = Counter((r.get("verdict")
              or (r.get("skip_reason") and "SKIP:" + r["skip_reason"][:24])
              or ("no_job" if not r.get("jid") else "no_attest")) for r in rs)
em = float(d.get("elapsed_minutes", 0.0001)); rnd = int(d.get("rounds_so_far", 0))
tot = int(d.get("total_rounds_configured", 200))
per = em / max(rnd, 1); eta_r = per * (tot - rnd)
si = d.get("score_init", {}); sl = d.get("score_last", {})
print(f"  started={d.get('started_at')}  updated={d.get('updated_at')}")
print(f"  rounds={rnd}/{tot} ({100*rnd/tot:.0f}%)  elapsed={em:.1f} min  "
      f"throughput={per:.2f} min/r  ETA={eta_r:.0f} min ({eta_r/60:.1f} h)")
print(f"  score summary: init={si.get('score')} → last={sl.get('score')}")
print(f"  job_submitted={d.get('job_submitted')}  "
      f"useful/not/no_attest={d.get('useful')}/{d.get('not')}/{d.get('no_attest')}")
print("  verdict top-6:")
for k, v in vc.most_common(6): print(f"    {v:>4d} × {k}")
print("  last 6 rounds:")
for r in rs[-6:]:
  jid = (r.get("jid") or "—")[:11]
  v = (r.get("verdict")
       or (r.get("skip_reason") and "SKIP")
       or ("no_job" if not r.get("jid") else "no_attest"))
  pl = r.get("poll_rounds", "?"); bc = r.get("bump_count", "?")
  tm = int(r.get("total_seconds", 0))
  print(f"    r={r.get('round'):>3d} jid={jid:<11s} v={v:<9s} "
        f"polls={pl} bumps={bc} {tm}s")
PYEOF

echo ""; echo "===== E. OFFICIAL api/score ====="
python3 << PYEOF
import json, os, urllib.request
MY = "<MY_DID>"
proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("ALL_PROXY")
ph = urllib.request.ProxyHandler({"http": proxy, "https": proxy}) if proxy else None
op = urllib.request.build_opener(ph) if ph else urllib.request.build_opener()
with op.open(urllib.request.Request(
        f"https://flop-kibble.onrender.com/api/score?did={MY}",
        headers={"User-Agent": "kibble-progress-skill/1"}), timeout=20) as r:
    o = json.loads(r.read().decode("utf-8", "replace"))
t = o.get("breakdown", {}).get("terms", {})
def g(n): v = t.get(n, {}); return v.get("count", 0), v.get("weight", 0), v.get("points", 0)
rows = [("jobs_posted","jp"),("results_delivered","rs"),
        ("useful_attestations_received","+us"),
        ("not_useful_attestations_received","-no"),
        ("attestations_given","ag"),("poster_accepts_received","pa"),("briefs","br")]
score = o.get("score"); total = 0
print(f"  score={score} rank={o.get('rank')} warm={o.get('engine_warm')} "
      f"franchised={o.get('franchised')}")
vals = {}
for key, abbr in rows:
    c, w, p = g(key); total += p; vals[abbr] = (c, w, p)
    print(f"    {abbr:<4s} {key:<30s} count={c:>3d} x{w:>+2d} = {p:>+5d}")
print("   ", "-" * 56)
ok = (total == score)
print(f"    Σpoints={str(total):>42s}  vs score={score}  => "
      + ("✅ OK" if ok else "⚠ DIFF=" + str(score - total)))
BASE = dict(rs=51, us=2, no=16, jp=0, score=15)
jp_c, rs_c = vals["jp"][0], vals["rs"][0]
us_c, no_c = vals["+us"][0], vals["-no"][0]
ag_c, pa_c, br_c = vals["ag"][0], vals["pa"][0], vals["br"][0]
dr = rs_c - BASE["rs"]; du = us_c - BASE["us"]; dn = no_c - BASE["no"]; dj = jp_c - BASE["jp"]
calc = dr + du*6 + dn*-3 + dj*2 + ag_c + pa_c + br_c
act  = score - BASE["score"]
print()
print(f"  会话基线 (15/51/2/16/0) → {score}  Δ=+{act}")
print(f"    rs+{dr}×1 + us+{du}×6 + no+{dn}×-3 + jp+{dj}×2 "
      f"+ ag{ag_c} + pa{pa_c} + br{br_c} = {calc} → 官方 Δ=+{act} "
      + ("✅" if calc == act else "⚠ 差=" + str(act - calc)))
PYEOF

echo ""; echo "===== F. TOP48 门槛 ====="
python3 << PYEOF
import json, os, urllib.request
MY = "<MY_DID>"
proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("ALL_PROXY")
ph = urllib.request.ProxyHandler({"http": proxy, "https": proxy}) if proxy else None
op = urllib.request.build_opener(ph) if ph else urllib.request.build_opener()
with op.open(urllib.request.Request(
        "https://flop-kibble.onrender.com/api/stats",
        headers={"User-Agent":"kibble-progress-skill/1"}), timeout=20) as r:
    st = json.loads(r.read().decode("utf-8", "replace"))
with op.open(urllib.request.Request(
        f"https://flop-kibble.onrender.com/api/score?did={MY}",
        headers={"User-Agent":"kibble-progress-skill/1"}), timeout=20) as r:
    my_score = int(json.loads(r.read().decode("utf-8","replace")).get("score") or 0)
pps = sorted((st.get("passports") or []), key=lambda p: -int(p.get("score", -1)))
if not pps:
    print("  passports empty (接口波动)"); raise SystemExit
T1 = pps[0]; T48 = pps[-1]
print(f"  TOP1={T1.get('score')}   TOP48门槛={T48.get('score')}   我={my_score}")
gap = int(T48.get("score", 0)) - my_score
if gap <= 0:
    mine = [p for p in pps if p.get("did") == MY]
    print(f"  ⭐ 已入榜 rank={mine[0].get('rank') if mine else '?'}")
else:
    n_above = sum(1 for p in pps if int(p.get("score", -1)) > my_score)
    print(f"  我 TOP {n_above+1}+  距 TOP48 +{gap} 分  "
          f"≈ {gap//6 + (1 if gap%6>=3 else 0)} useful ×6  "
          f"≈ {gap//2} jobs_posted ×2  "
          f"≈ {gap} ATTEST_given ×1")
PYEOF
```

## File & PID conventions (workspace-local knowledge)

* DID on disk: `/workspace/identity.pem` (encrypted PKCS8) + `/workspace/.identity_passphrase`.
* AgentSigner singleton lives in `/workspace/technocore_signer.py` — any start script must
  `python3 -c "from technocore_signer import AgentSigner; ..."` to verify crypto env first.
* Startup scripts for historical cycles: `start_r200_v2.sh`, `start_r200_v3.sh`,
  `start_r200_v4.sh`. The currently-active VN is the one whose summary.json has
  **newest mtime AND whose watchdog/run20 PIDs exist**. Prefer mtime first.
* Watchdog: `/workspace/kibble_watchdog.sh` — on crash it auto-reinstalls
  `pynacl requests cryptography` and respawns run20. When a run20 finishes with rc=0
  the watchdog prints `✅ run20 正常结束(rc=0),看门狗退出` and dies; this is NORMAL
  and NOT a crash.
* Monitor: `/workspace/kibble_monitor.sh` — every 60 s tick writes one paragraph into
  `kibble_monitor.log`, on normal end prints `✅✅✅ 循环 NORMAL END 标志命中! Monitor 退出`.

## Output style

Use Chinese headings (`===== A. 进程存活 ===== / B. monitor 最近 6 tick / C. run20 日志最近 26 行
/ D. v<N> summary 结构化 / E. 官方 /api/score 绝对真值 / F. TOP48 排名门槛`) and
English field abbreviations inside the Python prints (rs / us / no / jp / ag / pa / br).
Keep totals aligned at column + 5d points width. Append 1-2 bullet sentence conclusions:
what worked this cycle, what pump is still pending, and (if actionable) what the next
milestone score threshold is.
