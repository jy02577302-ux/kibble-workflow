#!/bin/bash
# v6 500 轮循环 + 双自守护 + franchise bootstrap
# =============================================================
#  v6 delta (相对 v5):
#    1. ROOM=kibble / BASE=technocore.chat 保持不变 (实锤接活站点)
#    2. V6_BOOTSTRAP_FRANCHISE=1: 启动即自闭环 3× JOB→CLAIM→DELIVER
#       满足 scoring caps.min_franchise_results=1, 使 franchised=True
#       解锁 own>=3 的 jobs_posted×2 + attests_given×1 权重
#    3. POST_EVERY_ROUNDS=3 (每 3 轮 1 批), POST_JOBS_PER_BATCH=20
#       500/3 ≈ 167 批 × 20 = 3340 JOB = 6680 分(入榜门槛仅 306)
#    4. VALIDATOR_LIMIT=3, ACCEPT_LIMIT=3 (保留 v5 激进值)
#    5. 双自守护: setsid watchdog1 → watchdog2(WATCH_THE_WATCHDOG) 每 5min
#       如果 watchdog/run20/monitor 全死, 重新安装依赖 + setsid 全部拉起
#    6. 对外查 score 仍走 flop-kibble.onrender.com (它是唯一公开 score API)
#       technocore.chat 工作 tape, flop 公开榜 = 分工如 flop 官方 llms.txt 所述
# =============================================================
set -u
cd /workspace

# 0. 清旧进程 (v5 等残留)
pkill -9 -f kibble 2>/dev/null || true
sleep 3
if pgrep -af kibble 2>/dev/null | grep -v -E "zsh|pgrep|start_r200_v6" > /dev/null; then
  echo "STILL ALIVE, retry..."
  pkill -9 -f kibble 2>/dev/null; sleep 3
fi
pgrep -af kibble 2>/dev/null | grep -v -E "zsh|pgrep|start_r200_v6" | head || echo "(no kibble procs)"
echo "[clean done]"

# 1. 依赖 (watchdog 也会补装, 启动前先行一次防网络抖动)
if ! /root/.pyenv/versions/3.14.7/bin/python3 -c "import nacl,requests,cryptography" 2>/dev/null; then
  echo "[install deps] pynacl+requests+cryptography"
  /root/.pyenv/versions/3.14.7/bin/python3 -m pip install --quiet --root-user-action=ignore pynacl requests cryptography 2>&1 | tail -2
fi

# 2. 备份 v5 产物(死循环快照也保留一份)
ts=$(date +%s)
for fn in kibble_r200_v5_summary.json kibble_r200_v5.log kibble_monitor_v5.log kibble_r200_v5_dead_*.json kibble_r200_v5_dead_*.log; do
  if [ -f "$fn" ]; then
    cp "$fn" "kibble_v5_backup_${ts}.${fn##*.}" 2>/dev/null || true
    echo "[backup] $fn → v5 backup ts=$ts"
  fi
done

# 3. 清空 v6 槽
rm -f kibble_r200_v6_summary.json kibble_r200_v6.log kibble_monitor_v6.log \
      kibble_attest_cache.json kibble_poster_accept_cache.json kibble_r200_v6_supervisor.log
echo "[v6 slots cleared]"

# 4. setsid 启动 watchdog (第 1 层)
export ROUNDS=500 TOTAL_MINUTES=0 SCAN_ROUNDS=6 POLL_ROUNDS=18 \
       VALIDATOR_LIMIT=3 \
       POST_EVERY_ROUNDS=3 POST_JOBS_PER_BATCH=20 ACCEPT_LIMIT=3 \
       V6_BOOTSTRAP_FRANCHISE=1 \
       SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json \
       PYENV_VERSION=3.14.7
setsid bash /workspace/kibble_watchdog.sh >> kibble_r200_v6.log 2>&1 < /dev/null &
WDPID=$!
echo "[watchdog start] setsid pid=$WDPID → kibble_r200_v6.log"

sleep 4

# 5. setsid 启动 monitor
setsid bash -c '
  LOG=/workspace/kibble_monitor_v6.log
  export SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json
  export RUN5H_LOG=/workspace/kibble_r200_v6.log
  exec bash /workspace/kibble_monitor.sh > "$LOG" 2>&1
' < /dev/null &
MNPID=$!
echo "[monitor start] pid=$MNPID → kibble_monitor_v6.log"

# 6. setsid 启动 SUPER WATCHDOG (watch the watchdog) — 第 2 层守护
#    每 5 分钟核一次; 如果 watchdog/run20 < 2 个, 就清装依赖 + 重启看门狗 + monitor
setsid bash -c '
  SVLOG=/workspace/kibble_r200_v6_supervisor.log
  echo "SUPERVISOR START @ $(date)" >> $SVLOG
  while true; do
    sleep 300
    alive_wd=$(pgrep -c -f "kibble_watchdog.sh" 2>/dev/null || echo 0)
    alive_r20=$(pgrep -c -f "kibble_run20.py" 2>/dev/null || echo 0)
    alive_mn=$(pgrep -c -f "kibble_monitor.sh" 2>/dev/null || echo 0)
    need_restart=0
    if [ "$alive_r20" -lt 1 ]; then need_restart=1; fi
    if [ "$alive_wd" -lt 1 ]; then need_restart=1; fi
    ts=$(date "+%Y-%m-%d %H:%M:%S")
    if [ "$need_restart" = "1" ]; then
      echo "[$ts] ⚠ WATCHDOG TRIP wd=$alive_wd r20=$alive_r20 mn=$alive_mn → RECOVERY" >> $SVLOG
      # 补依赖
      /root/.pyenv/versions/3.14.7/bin/python3 -c "import nacl,requests,cryptography" 2>/dev/null || \
        /root/.pyenv/versions/3.14.7/bin/python3 -m pip install --quiet --root-user-action=ignore pynacl requests cryptography 2>&1 | tail -1 >> $SVLOG
      # 清旧
      pkill -9 -f kibble 2>/dev/null; sleep 2
      export ROUNDS=500 TOTAL_MINUTES=0 SCAN_ROUNDS=6 POLL_ROUNDS=18 \
             VALIDATOR_LIMIT=3 POST_EVERY_ROUNDS=3 POST_JOBS_PER_BATCH=20 ACCEPT_LIMIT=3 \
             V6_BOOTSTRAP_FRANCHISE=1 \
             SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json PYENV_VERSION=3.14.7
      setsid bash /workspace/kibble_watchdog.sh >> /workspace/kibble_r200_v6.log 2>&1 < /dev/null &
      W2=$!
      export SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json RUN5H_LOG=/workspace/kibble_r200_v6.log
      setsid bash -c "exec bash /workspace/kibble_monitor.sh > /workspace/kibble_monitor_v6.log 2>&1" < /dev/null &
      M2=$!
      echo "[$ts] ✅ recovered watchdog=$W2 monitor=$M2" >> $SVLOG
    else
      echo "[$ts] ✅ OK wd=$alive_wd r20=$alive_r20 mn=$alive_mn" >> $SVLOG
    fi
  done
' < /dev/null >> /workspace/kibble_r200_v6_supervisor.log 2>&1 &
SUPID=$!
echo "[supervisor start] pid=$SUPID → kibble_r200_v6_supervisor.log (每 5 分钟心跳+自愈)"

# 7. 等待 franchise bootstrap + 首轮完成 (约 45-75 秒)
sleep 75

# 8. 启动验收报告
echo ""
echo "====== 验收 A: 进程 ======"
pgrep -af kibble 2>/dev/null | grep -v -E "zsh|pgrep|start_r200_v6" || echo "NO PROC (异常)"
echo ""
echo "====== 验收 B: v6 启动 banner + bootstrap 3×3 闭环 ======"
grep -E "KIBBLE RUN20 启动|初始 score|身份 DID|v6 激活|JOB [123]/3|CLAIM [123]/3|DELIVER [123]/3|bootstrap:" /workspace/kibble_r200_v6.log 2>/dev/null | head -n 20
echo ""
echo "====== 验收 C: v6 日志最新 16 行 (首轮/post/validator 触发否) ======"
tail -n 16 /workspace/kibble_r200_v6.log 2>/dev/null
echo ""
echo "====== 验收 D: monitor v6 tail 6 ======"
tail -n 6 /workspace/kibble_monitor_v6.log 2>/dev/null || echo "(空, monitor 首 tick 60s)"
echo ""
echo "====== 验收 E: supervisor 首条 ======"
head -n 2 /workspace/kibble_r200_v6_supervisor.log 2>/dev/null
echo ""
echo "====== 验收 F: summary v6 ======"
/root/.pyenv/versions/3.14.7/bin/python3 -c "
import json
try:
    d=json.load(open('/workspace/kibble_r200_v6_summary.json'))
    print('started:',d.get('started_at'))
    print('updated:',d.get('updated_at'))
    print('rounds:',d.get('rounds_so_far'),'/',d.get('total_rounds_configured'))
    print('job_submitted:',d.get('job_submitted'),'useful:',d.get('useful'))
except Exception as e: print('summary not ready:',e)
"
