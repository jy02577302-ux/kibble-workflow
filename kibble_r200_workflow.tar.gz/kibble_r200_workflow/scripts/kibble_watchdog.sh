#!/bin/bash
# ===============================================================
#  KIBBLE WATCHDOG · 抗 SIGKILL 自动重启看门狗 (最大 50 次)
#  - Python 异常或被 OOM/sandbox 回收杀掉时, 5s 后自动续跑
#  - 续跑时 kibble_run20.py 会读 SUMMARY_FILE 断点续接轮号+累计数
#  - 正常结束(时间到/轮数到 rc=0)则退出看门狗
#  用法(带环境变量):
#    TOTAL_MINUTES=300 SCAN_ROUNDS=8 POLL_ROUNDS=15 \
#      SUMMARY_FILE=/workspace/kibble_run5h_summary.json \
#      nohup bash /workspace/kibble_watchdog.sh > /workspace/kibble_run5h.log 2>&1 &
# ===============================================================
set +e

TOTAL_MINUTES=${TOTAL_MINUTES:-300}
SCAN_ROUNDS=${SCAN_ROUNDS:-8}
POLL_ROUNDS=${POLL_ROUNDS:-15}
SUMMARY_FILE=${SUMMARY_FILE:-/workspace/kibble_run5h_summary.json}
SCRIPT="/workspace/kibble_run20.py"
PYTHON_BIN="${PYTHON_BIN:-/root/.pyenv/versions/3.14.7/bin/python3}"
MAX_RESTARTS=50
RESTART_GAP=5

export TOTAL_MINUTES SCAN_ROUNDS POLL_ROUNDS SUMMARY_FILE

# ==== PYTHON 自检 & 自动装依赖 (解决沙箱每会话清空site-packages) ====
ensure_python_env() {
  # 1. PYTHON_BIN 可执行校验
  if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    echo "[WD $(date '+%H:%M:%S')] ⚠ PYTHON_BIN=$PYTHON_BIN 不存在,尝试系统python3..."
    PYTHON_BIN=$(command -v python3 2>/dev/null || echo "/usr/bin/python3")
  fi
  # 2. v3: 依赖扩展为 nacl + requests + cryptography (AgentSigner 用 cryptography Ed25519/PKCS8 PEM)
  #    之前只装 nacl/requests, 会导致 AgentSigner 启动失败 → cryptography Missing.
  if ! "$PYTHON_BIN" -c "import nacl,requests,cryptography" >/dev/null 2>&1; then
    echo "[WD $(date '+%H:%M:%S')] 📦 缺失,正在$PYTHON_BIN -m pip install pynacl requests cryptography ..."
    "$PYTHON_BIN" -m pip install --quiet --root-user-action=ignore pynacl requests cryptography 2>&1 | tail -3
    if "$PYTHON_BIN" -c "import nacl,requests,cryptography" >/dev/null 2>&1; then
      echo "[WD $(date '+%H:%M:%S')] ✅ 依赖安装成功 (pynacl+requests+cryptography)"
    else
      echo "[WD $(date '+%H:%M:%S')] ❌ 依赖安装仍失败 · 尝试备用 /usr/bin/python3..."
      /usr/bin/python3 -m pip install --quiet --root-user-action=ignore pynacl requests cryptography >/dev/null 2>&1
      if /usr/bin/python3 -c "import nacl,requests,cryptography" >/dev/null 2>&1; then
        PYTHON_BIN=/usr/bin/python3
        echo "[WD $(date '+%H:%M:%S')] ✅ 降级到 PYTHON_BIN=$PYTHON_BIN OK"
      fi
    fi
  fi
}

echo "================================================================"
echo "  🐕 KIBBLE WATCHDOG 启动 @ $(date '+%Y-%m-%d %H:%M:%S')"
echo "  上限: ${TOTAL_MINUTES}分钟 · 最大自重启: ${MAX_RESTARTS}次"
echo "  每次死进程后 ${RESTART_GAP}s 自动拉起"
echo "  Python: $PYTHON_BIN"
echo "================================================================"

restarts=0
while true; do
  # 每次拉 run20 前自检依赖(沙箱可能在运行中期清空site-packages)
  ensure_python_env

  echo ""
  echo "[WD $(date '+%H:%M:%S')] -------- 拉起 run20 (重启=$restarts) --------"

  $PYTHON_BIN -u "$SCRIPT"
  rc=$?

  if [ $rc -eq 0 ]; then
    echo "[WD $(date '+%H:%M:%S')] ✅ run20 正常结束(rc=0),看门狗退出"
    exit 0
  fi

  # ---- 退出码非 0 · 判断是时间到还是异常 ----
  # 判断 1: elapsed_minutes >= TOTAL_MINUTES-2 视为时间到
  if python3 -c "
import json,sys
try:
    d=json.load(open('$SUMMARY_FILE'))
    e=d.get('elapsed_minutes',0); t=d.get('total_minutes',0)
    sys.exit(0 if t>0 and e>=t-2 else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
    echo "[WD $(date '+%H:%M:%S')] ⏰ elapsed 已达 ${TOTAL_MINUTES} 分钟上限,看门狗退出"
    exit 0
  fi

  # 判断 2: 最大重启次数
  restarts=$((restarts+1))
  if [ $restarts -ge $MAX_RESTARTS ]; then
    echo "[WD $(date '+%H:%M:%S')] ❌ 超过最大重启 ${MAX_RESTARTS} 次,看门狗退出(rc=$rc)"
    exit $rc
  fi

  echo "[WD $(date '+%H:%M:%S')] 💥 run20 异常 rc=$rc · ${RESTART_GAP}s 后第 $restarts 次重启..."
  sleep $RESTART_GAP
done
