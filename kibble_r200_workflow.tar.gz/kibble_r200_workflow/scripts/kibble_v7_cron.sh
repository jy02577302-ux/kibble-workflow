#!/bin/bash
# V7 cron 级守护: 每分钟被 /etc/cron.d/kibble_v7 调一次, 若 wd 或 r20 或 mn 或 supervisor 任一缺失就重启全套
# 防并发: flock 自己
LOCK=/tmp/kibble_v7_cron.lock
exec 9>>$LOCK
if ! flock -n 9; then exit 0; fi

LOG=/workspace/kibble_v7_cron.log
print() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> $LOG; }

_count_proc() {
  # pgrep -c 的安全版: 排除 bash/sh/grep/pgrep 等解释器自身, 避免命令行中含匹配词被误算
  local pattern="$1"
  local n
  n=$(pgrep -f "$pattern" 2>/dev/null | while read -r p; do
    [ ! -r "/proc/$p/cmdline" ] && continue
    local cl
    cl=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
    # 跳过 bash/zsh/sh 作为直接解释器 (第一个 argv 是 shell 本身且后面是 -c 或 script 含 pattern 文本)
    local first
    first=$(awk '{print $1}' <<< "$cl")
    case "$first" in
      */bash|*/zsh|*/sh|*/dash) continue ;;
      bash|zsh|sh|dash) continue ;;
    esac
    echo "$p"
  done | wc -l)
  echo "${n:-0}"
}

alive_wd=$(_count_proc "kibble_watchdog.sh")
alive_r20=$(_count_proc "kibble_run20.py")
alive_mn=$(_count_proc "kibble_monitor.sh")
# supervisor 检测: 找 cmdline 里有 supervisor.log 的 bash (必须是存活 bash, 所以直接用 /proc/$p/exe 是否 bash)
alive_sv=0
for p in $(pgrep bash 2>/dev/null); do
  if [ -r /proc/$p/cmdline ]; then
    cl=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
    case "$cl" in *kibble_r200_v6_supervisor.log*) alive_sv=1; break ;; esac
  fi
done

total=$((alive_wd + alive_r20 + alive_mn + alive_sv))
if [ $total -ge 4 ]; then
  # 正常, 每 5 分钟才打印一次 OK (降噪声)
  if [ ! -f /tmp/kibble_v7_ok_ts ] || [ $(( $(date +%s) - $(cat /tmp/kibble_v7_ok_ts 2>/dev/null || echo 0) )) -ge 300 ]; then
    date +%s > /tmp/kibble_v7_ok_ts
    print "✅ OK wd=$alive_wd r20=$alive_r20 mn=$alive_mn sv=$alive_sv (total=$total)"
  fi
  exit 0
fi

# 有人死了: 补依赖 + 清旧进程 + 全量重启
print "⚠ TRIP wd=$alive_wd r20=$alive_r20 mn=$alive_mn sv=$alive_sv → RECOVERY"
# 补依赖
if ! /root/.pyenv/versions/3.14.7/bin/python3 -c "import nacl,requests,cryptography" 2>/dev/null; then
  /root/.pyenv/versions/3.14.7/bin/python3 -m pip install --quiet --root-user-action=ignore pynacl requests cryptography >> $LOG 2>&1
  print "📦 deps reinstall done"
fi
# 清旧
pkill -9 -f kibble 2>/dev/null
sleep 3
pkill -9 -f kibble 2>/dev/null
sleep 2
cd /workspace

# 清监控计数 OK 时间戳 (重启后立即重新报告)
rm -f /tmp/kibble_v7_ok_ts

# 环境变量: V6 同参 + V6_BOOTSTRAP_FRANCHISE=0 (重启不要再贴 3×3 bootstrap, 会重复 franchise)
export ROUNDS=500 TOTAL_MINUTES=0 SCAN_ROUNDS=6 POLL_ROUNDS=18 \
       VALIDATOR_LIMIT=3 POST_EVERY_ROUNDS=3 POST_JOBS_PER_BATCH=20 ACCEPT_LIMIT=3 \
       V6_BOOTSTRAP_FRANCHISE=0 \
       SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json PYENV_VERSION=3.14.7

# watchdog
setsid bash /workspace/kibble_watchdog.sh >> /workspace/kibble_r200_v6.log 2>&1 < /dev/null &
W2=$!
print "🐕 watchdog restarted pid=$W2"

sleep 4

# monitor (v6 专用路径)
export SUMMARY_FILE=/workspace/kibble_r200_v6_summary.json RUN5H_LOG=/workspace/kibble_r200_v6.log
setsid bash -c 'exec bash /workspace/kibble_monitor.sh > /workspace/kibble_monitor_v6.log 2>&1' < /dev/null &
M2=$!
print "📊 monitor restarted pid=$M2"

# 外层 supervisor (5 分钟心跳, 若 cron 也死=这是最后一道防线; 其实 cron 现在是主力但保留做叠加)
setsid bash -c '
  SVLOG=/workspace/kibble_r200_v6_supervisor.log
  echo "SUPERVISOR START @ $(date)" >> $SVLOG
  while true; do
    sleep 300
    alive_wd=$(pgrep -c -f "kibble_watchdog.sh" 2>/dev/null || echo 0)
    alive_r20=$(pgrep -c -f "kibble_run20.py" 2>/dev/null || echo 0)
    alive_mn=$(pgrep -c -f "kibble_monitor.sh" 2>/dev/null || echo 0)
    need_restart=0
    [ "$alive_r20" -lt 1 ] && need_restart=1
    [ "$alive_wd" -lt 1 ] && need_restart=1
    ts=$(date "+%Y-%m-%d %H:%M:%S")
    if [ "$need_restart" = "1" ]; then
      echo "[$ts] ⚠ SUPERVISOR TRIP wd=$alive_wd r20=$alive_r20 mn=$alive_mn → RECOVERY (交给 cron, 1 分钟内会拉起)" >> $SVLOG
    else
      echo "[$ts] ✅ OK wd=$alive_wd r20=$alive_r20 mn=$alive_mn" >> $SVLOG
    fi
  done
' < /dev/null &
S2=$!
print "🛡 supervisor restarted pid=$S2"
echo
