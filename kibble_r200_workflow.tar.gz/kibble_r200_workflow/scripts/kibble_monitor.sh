#!/bin/bash
# ================================================================
#  KIBBLE MONITOR · 短周期轮询 (每 60 秒 1 tick, MAX_TICKS=360=6h)
#  - 单一监控策略 · 绝不要 300/3600 长 sleep (经验 1419962)
#  - 输出: /workspace/kibble_monitor.log
#  - 告警关键字: ⚠💥⚡✅⏰
#  用法:  nohup bash /workspace/kibble_monitor.sh > /dev/null 2>&1 &
# ================================================================
set +e

LOG="/workspace/kibble_monitor.log"
SUMMARY_FILE="${SUMMARY_FILE:-/workspace/kibble_run5h_summary.json}"
RUN5H_LOG="${RUN5H_LOG:-/workspace/kibble_run5h.log}"
TICK_SEC=60
MAX_TICKS=360            # 6 小时兜底,防泄漏

# --- 初始化基线 ---
prev_job=0; prev_useful=0; prev_not=0; prev_rounds=0; prev_score=0
prev_log_lines=0

tick() {
  local n=$1
  local ts; ts=$(date '+%Y-%m-%d %H:%M:%S')
  local sep="────────────────────────────────────"

  # 1. 进程检查 (run20 和 watchdog 至少 1 个存在)
  local run20_pid wd_pid
  run20_pid=$(pgrep -f "kibble_run20.py" | head -1)
  wd_pid=$(pgrep -f "kibble_watchdog.sh" | head -1)
  local proc_ok=1
  if [ -z "$run20_pid" ] && [ -z "$wd_pid" ]; then proc_ok=0; fi

  # 2. summary 指标 (若存在)
  local rounds=0 job=0 useful=0 not=0 no=0 score=0 elapsed=0 updated=""
  if [ -f "$SUMMARY_FILE" ] && [ -s "$SUMMARY_FILE" ]; then
    read -r rounds job useful not no score elapsed updated < <( /root/.pyenv/versions/3.14.7/bin/python3 -c "
import json,sys
try:
 d=json.load(open('$SUMMARY_FILE'))
 sl=d.get('score_last',{}).get('score',0) or 0
 print(len(d.get('results',[])), d.get('job_submitted',0), d.get('useful',0), d.get('not',0), d.get('no_attest',0), sl, d.get('elapsed_minutes',0), d.get('updated_at',''))
except Exception as e:
 print('0 0 0 0 0 0 0')
" 2>/dev/null )
  fi

  # 3. 日志行数 & 末行时间戳 (判断是否在推进)
  local cur_lines=0 last_update=""
  if [ -f "$RUN5H_LOG" ]; then
    cur_lines=$(wc -l < "$RUN5H_LOG" 2>/dev/null || echo 0)
    last_update=$(stat -c "%y" "$RUN5H_LOG" 2>/dev/null | cut -c1-19)
  fi

  # === 输出 tick header ===
  echo "" >> "$LOG"
  echo "[$ts] tick $n/$MAX_TICKS $sep" >> "$LOG"
  echo "  进程: run20=${run20_pid:-OFF}  watchdog=${wd_pid:-OFF}" >> "$LOG"
  if [ "$proc_ok" = "0" ]; then
    echo "  💥 致命: run20 & watchdog 均无进程!" >> "$LOG"
  fi

  echo "  Summary: rounds=$rounds job=$job useful=$useful not=$not no_attest=$no score=$score elapsed=${elapsed}min" >> "$LOG"
  [ -n "$updated" ] && echo "           updated_at=$updated" >> "$LOG"
  echo "  日志: lines=$cur_lines  mtime=$last_update" >> "$LOG"

  # === 增量告警 ===
  if [ "$useful" -gt "$prev_useful" ] 2>/dev/null; then
    local delta=$(( useful - prev_useful ))
    echo "  ⚡⚡⚡ USEFUL 入账 +${delta}! 累计 useful=$useful (×6 分)" >> "$LOG"
  fi
  if [ "$not" -gt "$prev_not" ] 2>/dev/null; then
    local nd=$(( not - prev_not ))
    echo "  ❌ NOT +${nd} 累计 not=$not (-3 each)" >> "$LOG"
  fi
  if [ "$score" -gt "$prev_score" ] 2>/dev/null; then
    echo "  📈 SCORE ${prev_score}→${score} (+$(( score - prev_score )))" >> "$LOG"
  fi
  if [ "$job" -gt "$prev_job" ] 2>/dev/null; then
    echo "  ✅ JOB +$(( job - prev_job )) 累计提交 $job" >> "$LOG"
  fi

  # 日志停写 >= 10分钟且进程仍在 → 疑似卡住
  if [ -n "$last_update" ]; then
    local lu_epoch now_sec stale_min
    lu_epoch=$(date -d "$last_update" +%s 2>/dev/null || echo 0)
    now_sec=$(date +%s)
    stale_min=$(( (now_sec - lu_epoch) / 60 ))
    if [ "$stale_min" -ge 10 ] && [ -n "$run20_pid" ]; then
      echo "  ⚠ 疑似卡住: 日志已 $stale_min 分钟未更新 (PID $run20_pid 仍存活)" >> "$LOG"
    fi
  fi

  # 日志是否有致命错误关键词
  if [ -f "$RUN5H_LOG" ]; then
    local err_ct
    err_ct=$(grep -cEi "traceback|ModuleNotFoundError|No module named|killed|signal 9" "$RUN5H_LOG" 2>/dev/null)
    if [ "$err_ct" -gt 0 ] 2>/dev/null; then
      echo "  ⚠ 日志命中 $err_ct 次错误关键字 (ModuleNotFound/Traceback/SIGKILL)" >> "$LOG"
    fi
  fi

  # === 结束条件检测: 时间到或完成 ===
  if [ -n "$elapsed" ] && [ "${elapsed%%.*}" -ge 298 ] 2>/dev/null; then
    echo "  ⏰ 已达 300 分钟上限 (elapsed=${elapsed}min) — 5 小时循环即将结束" >> "$LOG"
  fi
  # watchdog 已正常退出信号: 日志尾有"看门狗退出"或RUN20完成标
  if [ -f "$RUN5H_LOG" ]; then
    if tail -5 "$RUN5H_LOG" 2>/dev/null | grep -qE "RUN20 完成|正常结束.*看门狗退出|时间到\(.*分钟上限\)"; then
      echo "  ✅✅✅ 循环 NORMAL END 标志命中! Monitor 退出" >> "$LOG"
      exit 0
    fi
  fi

  # 更新基线
  prev_rounds=$rounds; prev_job=$job; prev_useful=$useful; prev_not=$not; prev_score=$score; prev_log_lines=$cur_lines
}

# ===== 主循环: 60s × 360 ticks =====
echo "================================================================" >> "$LOG"
echo "  📡 KIBBLE MONITOR 启动 @ $(date '+%Y-%m-%d %H:%M:%S')  单策略 tick=$TICK_SEC s" >> "$LOG"
echo "  目标: $SUMMARY_FILE  主日志: $RUN5H_LOG" >> "$LOG"
echo "================================================================" >> "$LOG"

for (( n=1; n<=MAX_TICKS; n++ )); do
  tick $n
  [ $n -ge $MAX_TICKS ] && break
  sleep $TICK_SEC
done

echo "" >> "$LOG"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 🛑 Monitor 到达 MAX_TICKS=$MAX_TICKS, 自动退出" >> "$LOG"
