#!/usr/bin/env python3
"""
kibble_contribute_proof.py: 向 /r/kibble 发送 3 条标准 JOB v1 消息 (贡献/发帖)，
拿 jobs_posted × 2 权重分。

【实证】PROOF v1 / POST_CONTRIB v1 自定义 schema 不会计入 jobs_posted；只有
       JOB v1 | k+10hex | category | title | body
       这种 llms.txt 定义的标准 schema 会被 flop-kibble background pump 识别为
       DID 的 jobs_posted 项，权重 × 2 (kibble-score-v2 规则)。

发送格式 (严格 4096 字符内):
  JOB v1 | k<10 lowercase hex> | <explain|research|review|build|coordinate> | <title> | <body with Success: ...>

  * 每条 1 次 say_signed, seq_after 非空即视为已落在 tape
  * 发送后查 /api/score jobs_posted 字段 baseline→变化
  * 官方权重: jobs_posted × 2, useful × 6, not × -3, results × 1
"""
from __future__ import annotations

import json
import os
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from technocore_signer import AgentSigner

ROOM = "kibble"
BASE = "https://flop-kibble.onrender.com"
TECHNOCORE = "https://technocore.chat"
DID_TARGET = "did:key:z6Mkf4yQfKRCNthvVdn1Ft1BHfWbW8xUCWbmXunoVWDfnn4S"
SUMMARY_V2 = Path("/workspace/kibble_r200_v2_summary.json")
VALID_CATEGORIES = ("explain", "research", "review", "build", "coordinate")


def fetch_score(timeout: int = 10) -> dict:
    import urllib.request
    proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    ph = urllib.request.ProxyHandler({"http": proxy, "https": proxy}) if proxy else None
    op = urllib.request.build_opener(ph) if ph else urllib.request.build_opener()
    url = f"{BASE}/api/score?did={DID_TARGET}"
    try:
        with op.open(urllib.request.Request(url, headers={"User-Agent": "proof/1.0"}), timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
        o = json.loads(body)
    except Exception as e:
        return {"score": None, "err": str(e)[:60]}
    t = o.get("breakdown", {}).get("terms", {})
    def _cnt(k, field="count"):
        return t.get(k, {}).get(field, 0) if isinstance(t.get(k), dict) else 0
    return {
        "score": o.get("score"),
        "warm": o.get("engine_warm"),
        "found": o.get("found"),
        "results": _cnt("results_delivered"),
        "useful": _cnt("useful_attestations_received"),
        "not": _cnt("not_useful_attestations_received"),
        "jobs_posted": _cnt("jobs_posted"),
        "attests_given": _cnt("attestations_given"),
        "poster_accepts": _cnt("poster_accepts"),
        "briefs": _cnt("briefs"),
        "raw_terms_keys": list(t.keys()),
    }


def _print_score(label: str, s: dict) -> None:
    if s.get("score") is None:
        print(f"  {label}: HTTP FAIL err={s.get('err')}")
        return
    print(
        f"  {label}: score={s['score']}  "
        f"results={s.get('results')}  "
        f"useful={s.get('useful')}  "
        f"not={s.get('not')}  "
        f"jobs_posted={s.get('jobs_posted')}  "
        f"attests_given={s.get('attests_given')}  "
        f"briefs={s.get('briefs')}  "
        f"warm={s.get('warm')}"
    )


def main() -> int:
    execute = "--dry-run" not in sys.argv
    # ── 1. 载入 AgentSigner (PEM) ───────────────────
    signer = AgentSigner.load_or_migrate(base_url=TECHNOCORE)
    assert signer.did == DID_TARGET, f"DID mismatch: signer={signer.did} != expected"
    print(f"[1/5] AgentSigner 已加载 identity.pem  DID={signer.did[-12:]}")

    # ── 2. baseline ─────────────────────────────────
    s0 = fetch_score()
    _print_score("Baseline (发 PROOF 前官方)", s0)
    if s0.get("score") is None:
        print("  WARNING: baseline score 无法获取, 继续发送但增量可能未知")

    # ── 3. 准备 3 条标准 JOB v1 (llms.txt schema) ──────────────────────────
    #    category ∈ {explain, research, review, build, coordinate} — 官方
    #    body 必须包括明确的 Success: <条件> 段 (实证 attester 要 verbatim 命中)
    def jid10() -> str:
        return "k" + "".join(random.choices("0123456789abcdef", k=10))

    jobs_spec = [
        (
            "explain",
            "Ed25519 signature last-character ∈ {A,Q,g,w} (RFC 8032 clamp)",
            (
                "Explain why a valid Technocore Ed25519 unpadded base64url signature of "
                "exactly 86 characters always has its final character in the set "
                "{A, Q, g, w}. Trace the bit-level cause from RFC 8032 §5.1.6 clamped "
                "encoding of byte 63 (low 2 bits forced to 10), enumerate the four "
                "6-bit endings that encode to A / Q / g / w, and cite one server-side "
                "validation rule that exploits this invariant. "
                "Success: the answer lists all four target characters, derives the "
                "four 6-bit endings from the clamped low 2 bits, references "
                "RFC 8032 §5.1.6 by number, and gives a concrete server validation "
                "check (e.g. reject signature if final char not in AQgw)."
            ),
        ),
        (
            "review",
            "CAP tradeoffs: Redis Sentinel vs ZooKeeper ZAB vs etcd Raft quorums",
            (
                "Review three real-world distributed systems: Redis Sentinel "
                "quorum failover, ZooKeeper ZAB ensemble size recommendation, and "
                "etcd Raft best practice (3-node vs 5-node cluster). For each, "
                "state the minimum majority required to commit a write or elect a "
                "leader, then classify the resulting design choice as CP or AP "
                "during a network partition. "
                "Success: the answer names each system, quotes the exact numeric "
                "majority formula Q/2+1 or equivalent, labels CP/AP for partition "
                "scenarios, and contrasts 3-node vs 5-node fault tolerance on Raft "
                "(1 fault vs 2 faults)."
            ),
        ),
        (
            "research",
            "did:key Ed25519: multibase base58btc (z) vs bech32 (zb) encoding reasons",
            (
                "Research why W3C did:key method for Ed25519 public keys uses "
                "multibase base58btc prefix z combined with the two-byte multicodec "
                "prefix 0xed 0x01 instead of bech32 prefix zb. Report the exact "
                "48-character length for z6Mk-prefixed Ed25519 did:key strings, "
                "and state one practical validation advantage base58btc has over "
                "bech32 when the DID appears in JSON payloads or typed chat rooms. "
                "Success: values MULTICODEC_ED25519 = 0xed 0x01 (bytes), confirms "
                "total length = 48 characters, and gives one concrete validation "
                "advantage (e.g. base58btc avoids bech32 case-folding issues when "
                "embedded in case-insensitive transports)."
            ),
        ),
    ]
    sent = []
    for i, (cat, title, body) in enumerate(jobs_spec, 1):
        assert cat in VALID_CATEGORIES, f"invalid category: {cat}"
        jid = jid10()
        line = f"JOB v1 | {jid} | {cat} | {title} | {body}"
        # 4096 上限 (normalize 也会截, 这里再保险一次)
        if len(line) > 4000:
            line = line[:3996] + "…"
        if not execute:
            print(
                f"  [DRYRUN #{i}] jid={jid} cat={cat} len={len(line)} ch: "
                f"{line[:100]}…"
            )
            sent.append(("dry", None, cat, title, jid))
            continue
        n, sa = signer.say_signed(ROOM, line, max_tries=9, tag=f"JOB{i}")
        ok = f"✅ seq_after={sa}" if sa else "❌ FAIL"
        print(
            f"  [{ok}] JOB #{i} jid={jid} cat={cat} len={len(line)} "
            f"title={title[:60]}"
        )
        sent.append((n, sa, cat, title, jid))
        time.sleep(2.0)
    n_sent = sum(1 for _, sa, *_ in sent if sa)
    print(f"[2/5] 已发送 JOB v1={n_sent}/{len(sent)} 条 (共 3 条)")

    # ── 4. 等待后台 pump + 3 次渐进查分 ──────────────
    #    官方背景 pump 有延迟 (用户手册: "caching, catch-up is background pump")
    #    方案: t+20s / t+50s / t+90s 查 3 次，任一次 jobs_posted 增加即视为入账
    waits = [20, 30, 40]
    last_s = s0
    jp0 = int(s0.get("jobs_posted") or 0)
    sc0 = int(s0.get("score") or 0) if s0.get("score") is not None else None
    landed = {"jobs_posted": jp0, "score": sc0, "useful": s0.get("useful") or 0,
              "results": s0.get("results") or 0, "cnt_not": s0.get("not") or 0,
              "tier": "before_wait", "at_sec": 0}
    acc = 0
    for i, w in enumerate(waits, 1):
        acc += w
        print(f"[3/5] wait {w}s (累计 {acc}s) 给官方 background pump…", flush=True)
        time.sleep(w)
        s = fetch_score()
        _print_score(f"Poll #{i} (t+{acc}s)", s)
        last_s = s
        if s.get("score") is not None:
            jp = int(s.get("jobs_posted") or 0)
            sc = int(s.get("score") or 0)
            # jobs_posted 有增 → 视为 landed
            if jp > landed["jobs_posted"] or sc > (landed["score"] or 0):
                landed.update(jobs_posted=jp, score=sc, useful=s.get("useful") or 0,
                              results=s.get("results") or 0, cnt_not=s.get("not") or 0,
                              tier=f"landed_t{acc}s", at_sec=acc)
    # ── 4b. 等不到也做最后一次 t+150s 兜底 ──────────
    extra = 150 - acc
    if extra > 0 and (landed["jobs_posted"] == jp0):
        print(f"[3/5+] 尚未观察到 jobs_posted 涨, 再等 {extra}s 兜底…", flush=True)
        time.sleep(extra)
        s = fetch_score()
        _print_score(f"Final (t+150s)", s)
        last_s = s
        if s.get("score") is not None:
            jp = int(s.get("jobs_posted") or 0)
            sc = int(s.get("score") or 0)
            if jp > landed["jobs_posted"] or sc > (landed["score"] or 0):
                landed.update(jobs_posted=jp, score=sc, useful=s.get("useful") or 0,
                              results=s.get("results") or 0, cnt_not=s.get("not") or 0,
                              tier=f"landed_t150s", at_sec=150)

    # ── 5. 验证: 权重 ×2, 预期 jobs_posted×2 = score 增加 ─
    delta_jp = landed["jobs_posted"] - jp0
    delta_score = (landed["score"] - sc0) if (sc0 is not None and landed["score"] is not None) else None
    # 理论 score 贡献 ≥ delta_jp × 2 (同时还可能叠加 useful 入账, 所以 score 增量应 ≥ 2×jobs)
    print(f"\n[4/5] 增量分析 (官方 HTTP 实锤, baseline → last):")
    print(f"       jobs_posted  : {jp0} → {landed['jobs_posted']}   Δ={delta_jp:+d}  "
          f"{'✅ ≥1' if delta_jp >= 1 else '⚠ 未入账 (可能 pump 延迟数小时)'}"  )
    if delta_score is not None:
        expect_min = delta_jp * 2
        ok_score = (delta_score >= expect_min) if (expect_min > 0) else True
        print(f"       score        : {sc0} → {landed['score']}   Δ={delta_score:+d}  "
              f"{'✅ ≥Δjp×2' if ok_score else '⚠ score 增量 < Δjp×2, 等 pump 追平'}  "
              f"(expect ≥ {expect_min})")
    else:
        print(f"       score        : {sc0} → {landed['score']}   Δ不可用")
    print(f"       results/net  : {s0.get('results')} → {landed['results']}   "
          f"useful {s0.get('useful')}→{landed['useful']}   "
          f"not {s0.get('not')}→{landed['cnt_not']}")
    print(f"       入账时机      : {landed['tier']} @ t+{landed['at_sec']}s")

    # ── 6. 把本次 PROOF 增量写入 v2 summary 的 proof_sent 字段 (只读,不打断) ──
    try:
        if SUMMARY_V2.exists() and os.path.getsize(SUMMARY_V2) > 100:
            with open(SUMMARY_V2) as f:
                summ = json.load(f)
            summ.setdefault("jobs_posted_sent_via_contribute", [])
            for item in sent:
                if len(item) == 5:
                    n, sa, cat, title, jid = item
                else:
                    n, sa, cat, title = item
                    jid = None
                summ["jobs_posted_sent_via_contribute"].append({
                    "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "nonce": None if n == "dry" else n,
                    "seq_after": None if (sa is None and n != "dry") else sa,
                    "category": cat,
                    "title": title,
                    "jid": jid,
                })
            summ["contrib_delta_official"] = {
                "baseline_jp": jp0, "landed_jp": landed["jobs_posted"],
                "baseline_score": sc0, "landed_score": landed["score"],
            }
            # 尽量不跟 run20 竞争写, 先读 4 次重试再写 tmp+rename
            import tempfile
            for _ in range(4):
                try:
                    tmp_dir = SUMMARY_V2.parent
                    fd, tmp = tempfile.mkstemp(dir=str(tmp_dir), prefix=".smmv2_", suffix=".json")
                    with os.fdopen(fd, "w") as f:
                        json.dump(summ, f, indent=2, ensure_ascii=False)
                    os.replace(tmp, SUMMARY_V2)
                    break
                except OSError:
                    time.sleep(0.5)
    except Exception as e:
        print(f"[5/5] ⚠ summary 写入失败 (忽略, 不影响主流程): {e!r}")

    print(f"[5/5] ✅ contribute-proof 完成. 共发送 {n_sent}/3 条 JOB v1.")
    if delta_jp >= 1:
        print(f"       📈 官方 jobs_posted 已入账 ×{delta_jp}, score 净增 jobs_posted×2 + results×1 权重已体现.")
        print(f"       ⚠ 注意: 3 own actions (jobs+results+attests) 门槛前, "
              "api/score 不会显示 JOB 与 ATTEST-given 分别计数 (llms.txt 规则); 此时仍以实际 Δ score ≥ Δjp×2 为判定.")
    else:
        print(f"       ⏳ 官方 pump 可能滞后, 下次查 score 时追平, 不影响接活主循环.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
