#!/usr/bin/env python3
"""
AgentSigner: Technocore 统一签名类 (基于 technocore-did-starter 规范).
  - DID: did:key:z6Mk... (48-char multibase z + base58btc(0xed01 + 32B Ed25519 pub))
  - 签名载荷规范化: room|nonce(1~19digits)|normalize(text)
       normalize: 清除 Unicode Cc/Cf/Cs/Co/Zl/Zp 不可见字符 → ' ', strip, 长度≤4096
  - 签名结果: 64B Ed25519 → unpadded base64url (86 chars, 末字 ∈ {A,Q,g,w})
  - 私钥存储: PKCS8 PEM + BestAvailableEncryption(口令≥12char)
  - nonce: 单调递增, 持久化到 kibble_nonce.json (与 kibble_run20 旧格式完全兼容)
  - say_signed: HTTP GET /r/<room>/say-signed/<did>/<sig>/<nonce>/<urlencoded_text>
                 自动处理 422 duplicate, 重试与 sign_send(旧) 接口 100% 兼容

用法:
  signer = AgentSigner.load_or_migrate()  # 优先读 identity.pem, fallback 明文json(待迁移)
  nonce, seq_after = signer.say_signed("kibble", "CLAIM v1 | kXXX | worker", max_tries=8)
"""
from __future__ import annotations

import base64
import getpass
import json
import math
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable, Optional, Tuple

from cryptography.exceptions import InvalidSignature, UnsupportedAlgorithm
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

APP_VERSION = "1.0.0"
DEFAULT_BASE_URL = "https://technocore.chat"
DEFAULT_KEY_PATH = Path("/workspace/identity.pem")
DEFAULT_PLAIN_ID = Path("/workspace/technocore-identity.json")
DEFAULT_PASSPHRASE_FILE = Path("/workspace/.identity_passphrase")
DEFAULT_TIMEOUT_SECONDS = 25.0
MAX_MESSAGE_CHARS = 4096
MULTICODEC_ED25519 = b"\xed\x01"
MULTIBASE_LENGTH = 48
SIGNATURE_LENGTH = 86
BASE58BTC_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
BASE58BTC_INDEX = {c: i for i, c in enumerate(BASE58BTC_ALPHABET)}
INVISIBLE_CATEGORIES = frozenset({"Cc", "Cf", "Cs", "Co", "Zl", "Zp"})
NAME_PATTERN = re.compile(r"[a-z0-9][a-z0-9_-]{0,47}")
NONCE_PATTERN = re.compile(r"[0-9]{1,19}")
SIGNATURE_PATTERN = re.compile(rf"[A-Za-z0-9_-]{{{SIGNATURE_LENGTH}}}")
NONCE_FILE = "/workspace/kibble_nonce.json"


class IdentityError(ValueError):
    """The local identity cannot be created, loaded, or verified."""


class ProtocolError(ValueError):
    """An input does not satisfy the published Technocore protocol."""


class NetworkError(RuntimeError):
    """A Technocore HTTP request failed or returned an invalid response."""


# ──────────────────────────────────────────────────────────────
# 编码 / DID 基础函数
# ──────────────────────────────────────────────────────────────
def base58btc_encode(data: bytes) -> str:
    zeroes = len(data) - len(data.lstrip(b"\x00"))
    number = int.from_bytes(data, "big")
    encoded = ""
    while number:
        number, rem = divmod(number, 58)
        encoded = BASE58BTC_ALPHABET[rem] + encoded
    return "1" * zeroes + encoded


def base58btc_decode(value: str) -> bytes:
    number = 0
    for ch in value:
        try:
            digit = BASE58BTC_INDEX[ch]
        except KeyError as e:
            raise ProtocolError(f"invalid base58btc character: {ch!r}") from e
        number = number * 58 + digit
    decoded = number.to_bytes((number.bit_length() + 7) // 8, "big") if number else b""
    zeroes = len(value) - len(value.lstrip("1"))
    return b"\x00" * zeroes + decoded


def did_from_private_key(private_key: Ed25519PrivateKey) -> str:
    public_key = private_key.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    )
    multibase = "z" + base58btc_encode(MULTICODEC_ED25519 + public_key)
    if len(multibase) != MULTIBASE_LENGTH or not multibase.startswith("z6Mk"):
        raise IdentityError("generated an invalid Ed25519 did:key")
    return "did:key:" + multibase


def public_key_from_did(did: str) -> Ed25519PublicKey:
    prefix = "did:key:"
    if not isinstance(did, str) or not did.startswith(prefix):
        raise ProtocolError("DID must start with 'did:key:z6Mk'")
    mb = did[len(prefix):]
    if len(mb) != MULTIBASE_LENGTH or not mb.startswith("z6Mk"):
        raise ProtocolError("DID must be the canonical 48-char Ed25519 multibase form")
    dec = base58btc_decode(mb[1:])
    if len(dec) != 34 or not dec.startswith(MULTICODEC_ED25519):
        raise ProtocolError("DID must contain an ed25519-pub key")
    try:
        return Ed25519PublicKey.from_public_bytes(dec[2:])
    except ValueError as e:
        raise ProtocolError("DID contains invalid Ed25519 pubkey") from e


# ──────────────────────────────────────────────────────────────
# 规范化 / payload 构建
# ──────────────────────────────────────────────────────────────
def normalize_message(text: str) -> str:
    if not isinstance(text, str):
        raise ProtocolError("message text must be a string")
    normalized = "".join(
        " " if unicodedata.category(c) in INVISIBLE_CATEGORIES else c
        for c in text
    ).strip()
    if not normalized:
        raise ProtocolError("message has no visible text after normalization")
    if len(normalized) > MAX_MESSAGE_CHARS:
        # 超长时截断到最后一个完整词，避免中间切开
        normalized = normalized[:MAX_MESSAGE_CHARS].rstrip()
    return normalized


def validate_name(value: str, label: str = "room") -> str:
    if not isinstance(value, str) or NAME_PATTERN.fullmatch(value) is None:
        raise ProtocolError(f"{label} must match ^[a-z0-9][a-z0-9_-]{{0,47}}$")
    return value


def validate_nonce(value) -> str:
    nonce = str(value)
    if NONCE_PATTERN.fullmatch(nonce) is None:
        raise ProtocolError("nonce must contain 1-19 ASCII digits")
    return nonce


def message_payload(room: str, nonce, text: str) -> Tuple[str, bytes]:
    vr = validate_name(room)
    vn = validate_nonce(nonce)
    norm = normalize_message(text)
    return norm, f"{vr}|{vn}|{norm}".encode()


# ──────────────────────────────────────────────────────────────
# 签名 / 验签
# ──────────────────────────────────────────────────────────────
def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def sign_bytes(private_key: Ed25519PrivateKey, payload: bytes) -> str:
    enc = b64u(private_key.sign(payload))
    if SIGNATURE_PATTERN.fullmatch(enc) is None:
        raise IdentityError("generated invalid Ed25519 signature encoding")
    return enc


def verify_bytes(did: str, signature: str, payload: bytes) -> None:
    if SIGNATURE_PATTERN.fullmatch(signature or "") is None:
        raise ProtocolError("signature must contain 86 unpadded base64url characters")
    raw = base64.urlsafe_b64decode(signature + "==")
    try:
        public_key_from_did(did).verify(raw, payload)
    except InvalidSignature as e:
        raise IdentityError("signature does not match DID and payload") from e


# ──────────────────────────────────────────────────────────────
# 加密 PEM 身份创建 / 加载 (PKCS8 BestAvailableEncryption)
# ──────────────────────────────────────────────────────────────
def create_identity(path: Path, passphrase: str, private_key: Optional[Ed25519PrivateKey] = None) -> str:
    """Create encrypted PEM identity. If private_key given, use it (migrate mode)."""
    path = path.expanduser().resolve()
    if path.exists():
        raise IdentityError(f"refusing to overwrite existing identity: {path}")
    if not isinstance(passphrase, str) or len(passphrase) < 12:
        raise IdentityError("identity passphrase must contain at least 12 characters")
    enc_pp = passphrase.encode("utf-8")
    pk = private_key or Ed25519PrivateKey.generate()
    try:
        pem_bytes = pk.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.BestAvailableEncryption(enc_pp),
        )
        path.parent.mkdir(parents=True, exist_ok=True)
    except (OSError, ValueError) as e:
        raise IdentityError(f"cannot prepare encrypted identity {path}: {e}") from e
    desc: Optional[int] = None
    created = False
    try:
        desc = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True
        with os.fdopen(desc, "wb") as f:
            desc = None
            f.write(pem_bytes)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(path, 0o600)
    except FileExistsError as e:
        raise IdentityError(f"refusing to overwrite existing identity: {path}") from e
    except OSError as e:
        if desc is not None:
            try: os.close(desc)
            except OSError: pass
        cleanup_failed = False
        if created:
            try: path.unlink(missing_ok=True)
            except OSError: cleanup_failed = True
        detail = f"cannot write encrypted identity {path}: {e}"
        if cleanup_failed:
            detail += f"; remove the incomplete file manually: {path}"
        raise IdentityError(detail) from e
    return did_from_private_key(pk)


def _load_pem_key(pem_bytes: bytes, password: bytes) -> Any:
    try:
        return serialization.load_pem_private_key(pem_bytes, password=password)
    except UnsupportedAlgorithm as e:
        raise IdentityError("identity uses unsupported encryption") from e
    except (ValueError, TypeError) as e:
        raise IdentityError("incorrect passphrase or invalid encrypted identity") from e


def load_identity(path: Path, passphrase: Optional[bytes] = None,
                  allow_prompt: bool = True) -> Ed25519PrivateKey:
    resolved = path.expanduser().resolve()
    try:
        pem_bytes = resolved.read_bytes()
    except OSError as e:
        raise IdentityError(f"cannot read identity {resolved}: {e}") from e
    pw = passphrase
    if pw is None:
        try:
            loaded = serialization.load_pem_private_key(pem_bytes, password=None)
        except TypeError:
            if not allow_prompt:
                raise IdentityError("identity is encrypted and no passphrase provided") from None
            entered = getpass.getpass(f"Passphrase for {resolved}: ")
            pw = entered.encode("utf-8")
            loaded = _load_pem_key(pem_bytes, pw)
        else:
            raise IdentityError("unencrypted private keys are not supported")
    else:
        loaded = _load_pem_key(pem_bytes, pw)
    if not isinstance(loaded, Ed25519PrivateKey):
        raise IdentityError("identity must contain an Ed25519 private key")
    return loaded


def load_passphrase_from_file(pfile: Path) -> Optional[bytes]:
    if pfile.exists():
        try:
            data = pfile.read_bytes().strip()
            if data:
                return data
        except OSError:
            pass
    return None


# ──────────────────────────────────────────────────────────────
# nonce 持久化 (与旧 kibble_nonce.json 100% 兼容)
# ──────────────────────────────────────────────────────────────
def load_nonce() -> int:
    try:
        with open(NONCE_FILE) as f:
            return int(json.load(f).get("next_nonce", 0))
    except Exception:
        return int(time.time() * 1000)


def save_nonce(n: int) -> None:
    try:
        tmp = NONCE_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"next_nonce": n}, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, NONCE_FILE)
    except Exception:
        try:
            with open(NONCE_FILE, "w") as f:
                json.dump({"next_nonce": n}, f)
        except Exception:
            pass


# ──────────────────────────────────────────────────────────────
# AgentSigner 统一类
# ──────────────────────────────────────────────────────────────
class AgentSigner:
    """Unified signer for Technocore Chat.

    用法:
        s = AgentSigner(private_key, base_url=BASE)
        n, seq = s.say_signed(room, text, max_tries=4)
        # 或静态加载:
        s = AgentSigner.from_encrypted_pem(path, passphrase_bytes)
        s = AgentSigner.from_plain_seed(seed_hex)          # 仅迁移用
    """

    def __init__(self, private_key: Ed25519PrivateKey, base_url: str = DEFAULT_BASE_URL):
        self.private_key = private_key
        self.did = did_from_private_key(private_key)
        self.base_url = base_url.rstrip("/")
        proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
        self.opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy, "https": proxy}) if proxy else None
        )

    # ─── 类方法: 多种加载方式 ──────────────────────────────────
    @classmethod
    def from_encrypted_pem(cls, path=DEFAULT_KEY_PATH, passphrase: Optional[bytes] = None,
                           base_url: str = DEFAULT_BASE_URL) -> "AgentSigner":
        if passphrase is None:
            passphrase = load_passphrase_from_file(DEFAULT_PASSPHRASE_FILE)
        pk = load_identity(Path(path), passphrase=passphrase, allow_prompt=False)
        return cls(pk, base_url=base_url)

    @classmethod
    def from_plain_seed_hex(cls, seed_hex: str, base_url: str = DEFAULT_BASE_URL) -> "AgentSigner":
        """仅迁移期/自测用。实际生产用 from_encrypted_pem."""
        raw = bytes.fromhex(seed_hex)
        if len(raw) != 32:
            raise IdentityError(f"Ed25519 seed must be 32 bytes, got {len(raw)}")
        pk = Ed25519PrivateKey.from_private_bytes(raw)
        return cls(pk, base_url=base_url)

    @classmethod
    def from_plain_json(cls, path=DEFAULT_PLAIN_ID, base_url: str = DEFAULT_BASE_URL) -> "AgentSigner":
        with open(path) as f:
            ident = json.load(f)
        s = cls.from_plain_seed_hex(ident["private_seed_hex"], base_url=base_url)
        if s.did != ident.get("did", s.did):
            raise IdentityError(
                f"DID mismatch: derived={s.did} json={ident.get('did')}"
            )
        return s

    @classmethod
    def load_or_migrate(cls, base_url: str = DEFAULT_BASE_URL) -> "AgentSigner":
        """加载顺序: identity.pem → 明文 identity.json (向后兼容)."""
        if DEFAULT_KEY_PATH.exists():
            try:
                return cls.from_encrypted_pem(DEFAULT_KEY_PATH, base_url=base_url)
            except IdentityError:
                # 口令缺失/失败 → fallback 明文
                pass
        if DEFAULT_PLAIN_ID.exists():
            return cls.from_plain_json(DEFAULT_PLAIN_ID, base_url=base_url)
        raise IdentityError("no identity found (neither identity.pem nor technocore-identity.json)")

    # ─── 签名 & 验签 ─────────────────────────────────────────
    def sign_payload(self, payload: bytes) -> str:
        return sign_bytes(self.private_key, payload)

    def verify(self, signature: str, payload: bytes) -> None:
        verify_bytes(self.did, signature, payload)

    def build_say_url(self, room: str, nonce: int, text: str) -> Tuple[str, bytes, str]:
        """Return (url, signed_payload_bytes, signature_b64u)."""
        norm_text, payload = message_payload(room, nonce, text)
        sig = self.sign_payload(payload)
        enc = urllib.parse.quote(norm_text, safe="")
        url = f"{self.base_url}/r/{room}/say-signed/{self.did}/{sig}/{nonce}/{enc}"
        return url, payload, sig

    # ─── HTTP 发消息 ─────────────────────────────────────────
    def _http_get(self, url: str, timeout: float = DEFAULT_TIMEOUT_SECONDS) -> Tuple[int, str]:
        for i in range(2):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": f"AgentSigner/{APP_VERSION}"})
                with self.opener.open(req, timeout=timeout) as r:
                    return r.status, r.read().decode("utf-8", "replace")
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode("utf-8", "replace")
            except Exception:
                if i == 0:
                    time.sleep(1.5)
        return 0, "get_timeout"

    def _parse_seq_after(self, body: str) -> Optional[int]:
        # 路径 A: 标准 JSON 响应 (render 的 /api/signed 或特定 accept-header 返回)
        try:
            obj = json.loads(body)
            if isinstance(obj, dict):
                sa = obj.get("seq_after")
                if isinstance(sa, int):
                    return sa
        except Exception:
            pass
        # 路径 B: HTML/文本房间返回格式, 正则找 "seq_after":<digits> (可能 JSON 片段嵌入)
        m = re.search(r'"seq_after"\s*:\s*(\d+)', body)
        if m:
            return int(m.group(1))
        # 路径 C (fallback 实证): technocore.chat say-signed 返回房间 HTML
        #   第一行格式: "# room kibble  messages 20  range 702655..702674"
        #   或末尾 next 链接: "next: /r/kibble?since=702674"
        #   seq_after = range 上界 / since 值 (就是刚写入后最新 seq)
        #   如果是 PROOF 且在返回体里能看到 [702674] 的我 DID 消息, 就等于 seq_after=702675.
        head = re.search(r"range\s+\d+\.\.(\d+)", body)
        since = re.search(r"[?&]since=(\d+)", body)
        upper = head.group(1) if head else (since.group(1) if since else None)
        if upper:
            # 注意: say-signed 返回 range 结尾 = 刚 commit 的那条; seq_after 语义是
            # "本次提交后最新 seq" — 上下界语义上应该等于它本身
            return int(upper)
        return None

    def say_signed(self, room: str, text: str, max_tries: int = 4,
                   tag: str = "") -> Tuple[Optional[int], Optional[int]]:
        """签名并发送一条消息. 返回 (nonce_used, seq_after) 或 (None,None).

        与旧 kibble_run20.sign_send(text,tag,max_tries) 接口 100% 兼容:
          - nonce 单调, 基于 kibble_nonce.json
          - 遇 HTTP 422 duplicate: nonce+=2 重签重发
          - 其它失败: 指数退避 1→2→3...s 重试
          - 成功 / 失败都会 save_nonce(n+1) 保证单调
        """
        n = load_nonce()
        n = max(n, int(time.time() * 1000)) + 1
        for t in range(max_tries):
            url, _payload, _sig = self.build_say_url(room, n, text)
            s, b = self._http_get(url, timeout=DEFAULT_TIMEOUT_SECONDS)
            if s == 200:
                sa = self._parse_seq_after(b)
                save_nonce(n + 1)
                return n, sa
            elif s == 422 and "duplicate" in b.lower():
                n += 2
                continue
            else:
                time.sleep(1 + t)
                n += 1
        save_nonce(n + 1)
        return None, None


# ──────────────────────────────────────────────────────────────
# 自测 (python3 -m technocore_signer)
# ──────────────────────────────────────────────────────────────
def _selftest() -> int:
    print("[selftest] 1/5 生成临时 Ed25519 key...", end=" ", flush=True)
    pk = Ed25519PrivateKey.generate()
    s = AgentSigner(pk)
    assert s.did.startswith("did:key:z6Mk") and len(s.did) == 8 + 48, f"BAD did: {s.did}"
    print(f"OK did={s.did[-12:]}", flush=True)

    print("[selftest] 2/5 sign + verify round-trip (payload room|1|hello)...", end=" ", flush=True)
    norm, payload = message_payload("kibble", 1, "hello world")
    sig = s.sign_payload(payload)
    assert len(sig) == 86 and SIGNATURE_PATTERN.fullmatch(sig)
    s.verify(sig, payload)  # 不抛异常=通过
    try:
        verify_bytes(s.did, sig, b"kibble|1|not the same payload")
        print("FAIL - verify should have raised")
        return 1
    except IdentityError:
        pass
    print("OK", flush=True)

    print("[selftest] 3/5 不可见字符规范化: \u200b\u0000 tab → space 等处理...", end=" ", flush=True)
    n1 = normalize_message("a\u200bb\tc\u0001")
    assert "\u200b" not in n1 and "\t" not in n1
    assert n1 == "a b c", f"got {n1!r}"  # Cf + 两个 Cc 均替换为 space，每个不可见字符 1 space
    print("OK", flush=True)

    print("[selftest] 4/5 加密 PEM round-trip (临时 /tmp/tc_id.pem)...", end=" ", flush=True)
    tmp = Path("/tmp/tc_test_identity.pem")
    if tmp.exists(): tmp.unlink()
    pp = "TestPassw0rd!OK12"  # ≥12 字符
    pk2 = Ed25519PrivateKey.generate()
    did_in = create_identity(tmp, pp, pk2)
    assert tmp.stat().st_mode & 0o777 == 0o600, f"bad mode {oct(tmp.stat().st_mode)}"
    pk3 = load_identity(tmp, passphrase=pp.encode())
    did_back = did_from_private_key(pk3)
    assert did_in == did_back == did_from_private_key(pk2), f"DID round-trip mismatch"
    # 同 payload 签两次, 因为 Ed25519 deterministic 所以签名完全一致
    _, pl = message_payload("x", 9, "y")
    assert sign_bytes(pk2, pl) == sign_bytes(pk3, pl), "signatures must be identical for same key+payload"
    tmp.unlink(missing_ok=True)
    print("OK", flush=True)

    print("[selftest] 5/5 nonce 单调 + 持久化 (临时 nonce 文件)...", end=" ", flush=True)
    global NONCE_FILE
    orig_nf = NONCE_FILE
    NONCE_FILE = "/tmp/tc_test_nonce.json"
    if os.path.exists(NONCE_FILE): os.remove(NONCE_FILE)
    n1 = load_nonce()
    save_nonce(n1 + 42)
    n2 = load_nonce()
    assert n2 == n1 + 42, f"nonce persistence broken {n1}+42 → {n2}"
    os.remove(NONCE_FILE)
    NONCE_FILE = orig_nf
    print("OK", flush=True)

    print("\n✅ AgentSigner self-test ALL PASSED (5/5)")
    return 0


if __name__ == "__main__":
    if "--selftest" in sys.argv or len(sys.argv) == 1:
        sys.exit(_selftest())
